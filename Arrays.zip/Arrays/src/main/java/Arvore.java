public class Arvore {
    String especie;
    float altura;
    float diametro;
    float preco;
}
